
from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee
from .forms import EmployeeForm

def emp_list(request):
    employees = Employee.objects.all()
    return render(request, 'CRUDApp/emp_list.html', {'employees': employees})

def emp_create(request):
    form = EmployeeForm(request.POST or None)
    if form.is_valid():
        form.save()
        return redirect('emp_list')
    return render(request, 'CRUDApp/emp_form.html', {'form': form})

def emp_update(request, id):
    emp = get_object_or_404(Employee, id=id)
    form = EmployeeForm(request.POST or None, instance=emp)
    if form.is_valid():
        form.save()
        return redirect('emp_list')
    return render(request, 'CRUDApp/emp_form.html', {'form': form})

def emp_delete(request, id):
    emp = get_object_or_404(Employee, id=id)
    if request.method == 'POST':
        emp.delete()
        return redirect('emp_list')
    return render(request, 'CRUDApp/emp_confirm_delete.html', {'emp': emp})
