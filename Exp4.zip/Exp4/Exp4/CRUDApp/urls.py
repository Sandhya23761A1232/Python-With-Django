from django.urls import path
from . import views

urlpatterns = [
    path('', views.emp_list, name='emp_list'),
    path('add/', views.emp_create, name='emp_create'),
    path('edit/<int:id>/', views.emp_update, name='emp_update'),
    path('delete/<int:id>/', views.emp_delete, name='emp_delete'),
]
