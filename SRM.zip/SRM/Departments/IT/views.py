from django.shortcuts import render

def IT(request):
    return render(request, 'form.html')
