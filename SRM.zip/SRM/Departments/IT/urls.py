from django.urls import path
from . import views

urlpatterns = [
    path('IT/', views.IT, name='IT'),
]
