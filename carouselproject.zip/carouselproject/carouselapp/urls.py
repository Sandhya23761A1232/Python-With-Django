# carouselapp/urls.py
from django.urls import path
from . import views

app_name = 'carouselapp'

urlpatterns = [
    path('', views.home, name='home'),  # root of the app -> carousel page
]
