from django.apps import AppConfig


class CarouselappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'carouselapp'
